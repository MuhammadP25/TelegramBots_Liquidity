#!/bin/bash
python liquidity_bot.py
